local spawnedProp = nil

RegisterNetEvent('truth:spawnProp')
AddEventHandler('truth:spawnProp', function(propName)
    local playerPed = PlayerPedId()
    local playerCoords = GetEntityCoords(playerPed)
    local forwardOffset = 1.5 -- Distance in front of the player
    local propCoords = GetOffsetFromEntityInWorldCoords(playerPed, 0.0, forwardOffset, 0.0)
    local propHash = GetHashKey(propName)

    RequestModel(propHash)
    while not HasModelLoaded(propHash) do
        Citizen.Wait(0)
    end

    if spawnedProp then
        DeleteEntity(spawnedProp)
        spawnedProp = nil
    end

    spawnedProp = CreateObject(propHash, propCoords.x, propCoords.y, propCoords.z, true, true, true)
    PlaceObjectOnGroundProperly(spawnedProp)
    SetModelAsNoLongerNeeded(propHash)
    
    -- Notification for prop spawning
    TriggerEvent('chat:addMessage', { args = { '[PROP]', 'Prop spawned! Press E to delete.' } })

    -- Handle deleting prop with 'E' key
    Citizen.CreateThread(function()
        while spawnedProp do
            Citizen.Wait(0)
            if IsControlJustPressed(0, 38) then -- 'E' key
                DeleteEntity(spawnedProp)
                spawnedProp = nil
                TriggerEvent('chat:addMessage', { args = { '[PROP]', 'Prop deleted!' } })
            end
        end
    end)
end)
