ESX = exports['es_extended']:getSharedObject()

RegisterCommand('prop', function(source, args, rawCommand)
    local xPlayer = ESX.GetPlayerFromId(source)
    if xPlayer.getGroup() == 'admin' then
        if #args < 1 then
            TriggerClientEvent('chat:addMessage', source, { args = { '[PROP]', 'You need to specify a prop name.' } })
            return
        end
        local propName = args[1]
        TriggerClientEvent('truth:spawnProp', source, propName)
    else
        TriggerClientEvent('chat:addMessage', source, { args = { '[PROP]', 'You do not have permission to use this command.' } })
    end
end, false)
